Apache-2.0

This project is licensed under the Apache License 2.0.
See <https://www.apache.org/licenses/LICENSE-2.0>.
